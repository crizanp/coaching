<?php

return [
    'test' => 'This is a test translation',
];