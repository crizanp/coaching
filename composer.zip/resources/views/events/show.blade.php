@extends('layouts.frontend')

@section('title')
{{ $event->getLocalizedTranslation('title', app()->getLocale()) }} - {{ \App\Models\Setting::get('site_name')[app()->getLocale()] ?? 'SSJCHRYSALIDE' }}
@endsection

@section('description')
{{ $event->getLocalizedTranslation('seo_description', app()->getLocale()) ?: $event->getLocalizedTranslation('description', app()->getLocale()) }}
@endsection

@section('keywords')
atelier, événement, {{ $event->type }}, développement personnel, bien-être, Martinique
@endsection

@section('content')
<!-- Event Hero Section -->
<section class="section-padding" style="background: var(--light-pink); margin-top: 94px;">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-lg-10">
                <div class="fade-in">
                    <div class="mb-3">
                        <span class="badge bg-primary px-3 py-2">
                            {{ ucfirst($event->type) }} - {{ ucfirst($event->status) }}
                        </span>
                    </div>
                    <h1 class="section-title">{{ $event->getLocalizedTranslation('title', app()->getLocale()) }}</h1>
                    <p class="lead mb-4">{{ $event->getLocalizedTranslation('description', app()->getLocale()) }}</p>
                    
                    @if($event->can_register)
                    <div class="mt-4">
                        <a href="{{ route('events.apply', ['locale' => app()->getLocale(), 'event' => $event->slug]) }}" 
                           class="btn btn-primary btn-lg px-5 py-3">
                            <i class="fas fa-user-plus me-2"></i>
                            {{ __('messages.events.register_now') }}
                        </a>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Event Details -->
<section class="section-padding" style="background: white;">
    <div class="container">
        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8 mb-4">
                <!-- Featured Image -->
                @if($event->featured_image && file_exists(storage_path('app/public/' . $event->featured_image)))
                <div class="practice-card-textured mb-4" style="border-radius: 20px; overflow: hidden;">
                    <img src="{{ asset('storage/' . $event->featured_image) }}" 
                         alt="{{ $event->getLocalizedTranslation('title', app()->getLocale()) }}"
                         class="w-100" style="height: 400px; object-fit: cover;">
                </div>
                @endif
                
                <!-- Content -->
                <div class="practice-card-textured mb-4">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-info-circle"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.about_event') }}</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        {!! nl2br(e($event->getLocalizedTranslation('content', app()->getLocale()))) !!}
                    </div>
                </div>

                <!-- Workshop Transformation Section -->
                @if($event->type === 'workshop' || $event->type === 'atelier')
                <div class="practice-card-textured mb-4">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-sparkles"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>Une expérience transformante</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        <div class="transformation-highlights">
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="transformation-item">
                                        <div class="d-flex align-items-start">
                                            <div class="transformation-icon me-3">
                                                <i class="fas fa-heart"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-2" style="color: var(--primary-pink); font-weight: 600;">Découverte émotionnelle</h6>
                                                <p class="mb-0">Apprenez à reconnaître et accueillir vos émotions avec bienveillance</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="transformation-item">
                                        <div class="d-flex align-items-start">
                                            <div class="transformation-icon me-3">
                                                <i class="fas fa-search"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-2" style="color: var(--primary-pink); font-weight: 600;">Compréhension profonde</h6>
                                                <p class="mb-0">Identifiez les besoins cachés derrière chaque émotion et comportement</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="transformation-item">
                                        <div class="d-flex align-items-start">
                                            <div class="transformation-icon me-3">
                                                <i class="fas fa-comments"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-2" style="color: var(--primary-pink); font-weight: 600;">Communication authentique</h6>
                                                <p class="mb-0">Développez une communication plus authentique et bienveillante</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="transformation-item">
                                        <div class="d-flex align-items-start">
                                            <div class="transformation-icon me-3">
                                                <i class="fas fa-users"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-2" style="color: var(--primary-pink); font-weight: 600;">Relations harmonieuses</h6>
                                                <p class="mb-0">Créez des liens plus profonds avec vos proches et collègues</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4 p-4 rounded-3" style="background: rgba(255, 182, 193, 0.1); border-left: 4px solid var(--primary-pink);">
                            <p class="mb-0" style="font-style: italic; color: #6c757d;">
                                <i class="fas fa-quote-left me-2" style="color: var(--primary-pink);"></i>
                                "Chaque participant repart avec les clés concrètes pour transformer ses relations et mieux vivre ses émotions au quotidien."
                                <i class="fas fa-quote-right ms-2" style="color: var(--primary-pink);"></i>
                            </p>
                        </div>
                    </div>
                </div>
                @endif
                
                <!-- Benefits -->
                @if($event->benefits && ($benefitsTranslation = $event->getLocalizedTranslation('benefits', app()->getLocale())) && (is_array($benefitsTranslation) ? count($benefitsTranslation) : !empty($benefitsTranslation)) > 0)
                <div class="practice-card-textured mb-4">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.benefits') }}</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        <div class="row">
                            @foreach($event->getLocalizedTranslation('benefits', app()->getLocale()) as $benefit)
                            <div class="col-md-6 mb-3">
                                <div class="d-flex align-items-start">
                                    <i class="fas fa-check me-3 mt-1" style="color: var(--primary-pink);"></i>
                                    <span>{{ $benefit }}</span>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif
                
                <!-- Program -->
                @if($event->program && ($programTranslation = $event->getLocalizedTranslation('program', app()->getLocale())) && (is_array($programTranslation) ? count($programTranslation) : !empty($programTranslation)) > 0)
                <div class="practice-card-textured mb-4">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-list-ol"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.program') }}</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        <div class="program-list">
                            @foreach($event->getLocalizedTranslation('program', app()->getLocale()) as $index => $item)
                            <div class="program-item d-flex align-items-start mb-3">
                                <span class="badge bg-primary me-3 mt-1" style="border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">
                                    {{ $index + 1 }}
                                </span>
                                <span>{{ $item }}</span>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif
                
                <!-- Requirements -->
                @if($event->requirements && ($requirementsTranslation = $event->getLocalizedTranslation('requirements', app()->getLocale())) && (is_array($requirementsTranslation) ? count($requirementsTranslation) : !empty($requirementsTranslation)) > 0)
                <div class="practice-card-textured mb-4">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.requirements') }}</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        <ul class="list-unstyled">
                            @foreach($event->getLocalizedTranslation('requirements', app()->getLocale()) as $requirement)
                            <li class="mb-2">
                                <i class="fas fa-dot-circle me-2" style="color: var(--primary-pink);"></i>
                                {{ $requirement }}
                            </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                @endif
                
                <!-- Gallery -->
                @php
                    $validGalleryImages = [];
                    if($event->gallery && (is_array($event->gallery) ? count($event->gallery) : !empty($event->gallery)) > 0) {
                        foreach($event->gallery as $image) {
                            if($image && file_exists(storage_path('app/public/' . $image))) {
                                $validGalleryImages[] = $image;
                            }
                        }
                    }
                @endphp
                @if(count($validGalleryImages) > 0)
                <div class="practice-card-textured">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-images"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.gallery') }}</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        <div class="row">
                            @foreach($validGalleryImages as $image)
                            <div class="col-md-4 mb-3">
                                <div class="gallery-item" style="border-radius: 15px; overflow: hidden; transition: transform 0.3s ease;">
                                    <img src="{{ asset('storage/' . $image) }}" 
                                         alt="{{ $event->getLocalizedTranslation('title', app()->getLocale()) }}"
                                         class="w-100" style="height: 200px; object-fit: cover;">
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif
            </div>
            
            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Event Info -->
                <div class="practice-card-textured mb-4">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.event_info') }}</h4>
                        </div>
                    </div>
                    <div class="content-description"style="padding: 0 20px 20px 20px;">
                    
                        @if($event->event_date)
                        <div class="service-detail-item mb-3">
                            <strong>{{ __('messages.events.date') }}:</strong> {{ $event->event_date->format('d/m/Y') }}
                        </div>
                        <div class="service-detail-item mb-3">
                            <strong>{{ __('messages.events.time') }}:</strong> {{ $event->event_date->format('H:i') }}
                        </div>
                        @endif
                        
                        @if($event->duration)
                        <div class="service-detail-item mb-3">
                            <strong>{{ __('messages.events.duration') }}:</strong> {{ $event->duration }}
                        </div>
                        @endif
                        
                        @if($event->price)
                        <div class="service-detail-item mb-3">
                            <strong>{{ __('messages.events.price') }}:</strong> {{ number_format((float)$event->price, 2) }}€
                        </div>
                        @endif
                        
                        @if($event->max_participants)
                        <div class="service-detail-item mb-3">
                            <strong>{{ __('messages.events.participants') }}:</strong> {{ $event->current_participants }}/{{ $event->max_participants }}
                            <br><small class="text-success">{{ $event->available_spots }} {{ __('messages.events.spots_left') }}</small>
                        </div>
                        @endif
                        
                        @php
                            $locationTranslation = $event->getLocalizedTranslation('location', app()->getLocale());
                        @endphp
                        @if($locationTranslation && !empty($locationTranslation))
                        <div class="service-detail-item mb-3">
                            <strong>{{ __('messages.events.location') }}:</strong>
                            @if(is_array($locationTranslation))
                                @foreach($locationTranslation as $key => $value)
                                    @if($value)
                                        <div>{{ $value }}</div>
                                    @endif
                                @endforeach
                            @else
                                {{ $locationTranslation }}
                            @endif
                        </div>
                        @endif
                        
                        @if($event->registration_deadline)
                        <div class="service-detail-item mb-3">
                            <strong>{{ __('messages.events.deadline') }}:</strong> 
                            <span class="text-danger">{{ $event->registration_deadline->format('d/m/Y') }}</span>
                        </div>
                        @endif
                    </div>
                </div>
                
                <!-- Registration Card -->
                @if($event->can_register)
                <div class="practice-card-textured mb-4" style="background: var(--light-pink);">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.quick_register') }}</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        <p class="mb-4">{{ __('messages.events.register_description') }}</p>
                        <a href="{{ route('events.apply', ['locale' => app()->getLocale(), 'event' => $event->slug]) }}" 
                           class="btn btn-primary w-100">
                            <i class="fas fa-user-plus me-2"></i>
                            {{ __('messages.events.register_button') }}
                        </a>
                    </div>
                </div>
                @elseif($event->is_full)
                <div class="alert alert-warning">
                    <h6 class="fw-bold mb-2">{{ __('messages.events.event_full') }}</h6>
                    <p class="mb-0 small">{{ __('messages.events.event_full_description') }}</p>
                </div>
                @elseif(!$event->allow_registration)
                <div class="alert alert-info">
                    <h6 class="fw-bold mb-2">{{ __('messages.events.registration_closed') }}</h6>
                    <p class="mb-0 small">{{ __('messages.events.contact_for_info') }}</p>
                </div>
                @endif
                
                <!-- Contact Card -->
                <div class="practice-card-textured">
                    <div class="practice-card-body">
                        <div class="practice-icon-left">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="practice-card-content">
                            <h4>{{ __('messages.events.need_help') }}</h4>
                        </div>
                    </div>
                    <div class="content-description">
                        <p class="mb-3">{{ __('messages.events.contact_description') }}</p>
                        <a href="{{ route('contact.index', app()->getLocale()) }}" 
                           class="btn btn-outline-primary w-100">
                            <i class="fas fa-envelope me-2"></i>
                            {{ __('messages.events.contact_us') }}
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@push('styles')
<style>
    .practice-card-textured {
        background: #ffffff;
        border-radius: 20px;
        padding: 30px;
        text-align: left;
        border: 1px solid #000000;
        position: relative;
        overflow: hidden;
        transition: transform 0.25s ease;
        color: var(--text-dark);
    }

    .practice-card-textured::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-image: repeating-linear-gradient(
            45deg,
            rgba(0,0,0,0.01),
            rgba(0,0,0,0.01) 12px,
            rgba(255,255,255,0.01) 12px,
            rgba(255,255,255,0.01) 24px
        );
        opacity: 0.08;
        pointer-events: none;
    }

    .practice-card-textured:hover {
        transform: translateY(-4px);
        border-color: rgba(0,0,0,0.85);
    }

    .practice-icon-left {
        width: 60px;
        height: 60px;
        background: transparent;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
        color: #000000;
        margin-bottom: 0;
        position: relative;
        z-index: 1;
        box-shadow: none;
    }

    .practice-card-textured h4 {
        color: #1e1d1dff;
        font-weight: 600;
        font-size: 1.3rem;
        margin-bottom: 15px;
        position: relative;
        z-index: 1;
    }

    .practice-card-body {
        display: flex;
        gap: 16px;
        align-items: center;
        margin-bottom: 20px;
    }

    .practice-card-content {
        flex: 1 1 auto;
    }

    .content-description {
        color: #6c757d;
        font-size: 1rem;
        line-height: 1.7;
        margin-bottom: 20px;
        position: relative;
        z-index: 1;
        padding: 0 20px 20px 20px;
    }

    .service-detail-item {
        color: #6c757d;
        font-size: 0.95rem;
    }

    .gallery-item:hover {
        transform: scale(1.05);
    }

    /* Transformation Section Styles */
    .transformation-highlights {
        margin-top: 10px;
    }

    .transformation-item {
        padding: 15px;
        border-radius: 12px;
        transition: all 0.3s ease;
        background: rgba(255, 182, 193, 0.05);
        border: 1px solid rgba(255, 182, 193, 0.2);
    }

    .transformation-item:hover {
        background: rgba(255, 182, 193, 0.1);
        border-color: rgba(255, 182, 193, 0.3);
        transform: translateY(-2px);
    }

    .transformation-icon {
        width: 40px;
        height: 40px;
        background: var(--primary-pink);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.2rem;
        flex-shrink: 0;
    }

    .transformation-item h6 {
        font-size: 1rem;
        line-height: 1.3;
    }

    .transformation-item p {
        font-size: 0.9rem;
        line-height: 1.4;
        color: #6c757d;
    }

    @media (max-width: 767px) {
        .practice-card-body {
            flex-direction: column;
            gap: 12px;
        }
        .practice-icon-left {
            width: 56px;
            height: 56px;
            font-size: 1.6rem;
        }
        
        .transformation-item {
            padding: 12px;
            margin-bottom: 15px;
        }
        
        .transformation-icon {
            width: 35px;
            height: 35px;
            font-size: 1rem;
        }
        
        .transformation-item h6 {
            font-size: 0.95rem;
        }
        
        .transformation-item p {
            font-size: 0.85rem;
        }
    }
</style>
@endpush

@endsection